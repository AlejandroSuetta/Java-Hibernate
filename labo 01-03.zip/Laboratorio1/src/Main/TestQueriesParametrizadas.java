package Main;

import java.util.List;
import modelo.Auto;
import org.hibernate.Query;
import org.hibernate.Session;

public class TestQueriesParametrizadas {
    public static List obtenerAutosSegunCriterio(Session s, String unModelo, String unaMarca) {
        if((unModelo == null && unaMarca == null) || (unModelo.isEmpty() && unaMarca.isEmpty())) {
            Query paramQuery2 = s.createQuery("from Auto");
            List<Auto> autos = paramQuery2.list();
            for(Auto a : autos) {
                System.out.println("Marca: " + a.getMarca());
                System.out.println("Modelo: " + a.getModelo());
            }
            return autos;
        }
        Query paramQuery = s.createQuery("from Auto as a " 
                + "where a.modelo like :modeloX or a.marca like :marcaX");
        paramQuery.setString("modeloX", "%" + unModelo + "%");
        paramQuery.setString("marcaX", "%" + unaMarca + "%");
        List<Auto> autos = paramQuery.list();
        for(Auto a : autos) {
            System.out.println("Marca: " + a.getMarca());
            System.out.println("Modelo: " + a.getModelo());
        }
        return autos;
    }
}
