package modelo;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@NamedQueries({
    @NamedQuery(
        name = "obtenerAutosCaros",
        query = "from Auto as a where precio > 10000"  
    )
})

@Entity
public class Auto {
    
    @Id //Indicar que es un ID a Hibernate y PrimaryKey
    @GeneratedValue //Autogenerar ID
    private Long id;
    private String marca;
    private Date fecha;
    private int precio;

    public Auto() {
    }

    public Auto(String marca, Date fecha, int precio, String modelo) {
        this.id = id;
        this.marca = marca;
        this.fecha = fecha;
        this.precio = precio;
        this.modelo = modelo;
    }

    private String modelo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
}
