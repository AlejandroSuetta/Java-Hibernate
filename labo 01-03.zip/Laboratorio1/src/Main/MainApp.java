package Main;

import conf.MiHibernateUtil;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import modelo.Auto;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class MainApp {

    public static void main(String[] args) throws ParseException {

        SessionFactory sf = MiHibernateUtil.getSessionFactory();

        Session session = sf.openSession();
        Transaction t = session.beginTransaction();
        
        
 /*     //Crear registro en la BBDD
        Auto auto = new Auto("Audi","A5");
        session.save(auto);        
        System.out.println("ID:"+auto.getId());
 */

 /*   //Modificar registro en la BBDD
        Long idBuscar=1L;
        //Indicar a Hibernate que tiene de clase quiere que regrese
        Auto auto =(Auto) session.get(Auto.class, idBuscar);        
        p.setModelo("Mustang");
        session.update(auto);
*/
        
 /*       
   //Borrar un registro de la BBDD
         Long idBuscar=1L;
         Auto auto =(Auto) session.get(Auto.class, idBuscar);
         session.delete(auto);
*/

       //Obtener una lista de personas
      
        //HQL con createQuery, Colocar el nombre de la clase       
        //List<Auto> autos = session.createQuery("from Auto").list();
        //System.out.println("*******************REGISTROS*********************");
        //for (Auto obj : autos){            
        //    System.out.println("Nombre: "+obj.toString());
        //}
        /*
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha1 = dateFormat.parse("01/12/2018");
        Date fecha2 = dateFormat.parse("01/12/2010");
        Date fecha3 = dateFormat.parse("01/12/202");
        Date fecha4 = dateFormat.parse("01/12/2020");
        Date fecha5 = dateFormat.parse("01/12/2000");
        
        Auto auto1 = new Auto("Audi", fecha1, 200000, "A5");
        session.save(auto1);        
        System.out.println("ID:"+auto1.getId());
        
        Auto auto2 = new Auto("Volkswagen", fecha2, 25520, "Gol");
        session.save(auto2);        
        System.out.println("ID:"+auto2.getId());
        
        Auto auto3 = new Auto("Renault", fecha3, 50000, "Sandero");
        session.save(auto3);        
        System.out.println("ID:"+auto3.getId());
        
        Auto auto4 = new Auto("Ford", fecha4, 1000000, "Fiesta");
        session.save(auto4);        
        System.out.println("ID:"+auto4.getId());
        
        Auto auto5 = new Auto("Chevrolette", fecha5, 1000, "Corvette");
        session.save(auto5);        
        System.out.println("ID:"+auto5.getId());
        
        
        
        Query query1 = session.createQuery("from Auto as a order by a.fecha desc");
        List<Auto> resultado1 = query1.list();
        for(Auto a1 : resultado1) {
            System.out.println("Fecha: " + a1.getFecha() + "; Marca: " + a1.getMarca() + "; Modelo: " + a1.getModelo());
        }
        
        Query query2 = session.createQuery("from Auto as a where a.fecha > 2002/01/01 and a.fecha < 2003/01/01 ");
        List<Auto> resultado2 = query2.list();
        for(Auto a2 : resultado2) {
            System.out.println("Marca: " + a2.getMarca() + "; Modelo: " + a2.getModelo());
        }
        
        Query query3 = session.createQuery("from Auto as a where modelo = 'Fiesta'");
        List<Auto> resultado3 = query3.list();
        for(Auto a3 : resultado3) {
            System.out.println("Marca: " + a3.getMarca() + "; Modelo: " + a3.getModelo());
        }
        
        Query query4 = session.createQuery("from Auto as a where a.marca like 'C%'");
        List<Auto> resultado4 = query4.list();
        for(Auto a4 : resultado4) {
            System.out.println("Marca: " + a4.getMarca() + "; Modelo: " + a4.getModelo());
        }
       
        Query query5 = session.createQuery("from Auto as a where a.precio > 15000");
        List<Auto> resultado5 = query5.list();
        for(Auto a5 : resultado5) {
            System.out.println("Marca: " + a5.getMarca() + "; Modelo: " + a5.getModelo());
        }
        
        Query query6 = session.createQuery("select count(*) from Auto");
        long resultado6 = (Long) query6.uniqueResult();
        System.out.println("Cantidad: " + resultado6);
        
        Query query7 = session.createQuery("");
        
        
        Query query8 = session.createQuery("select max(a.precio) from Auto as a");
        int resultado8 = (Integer) query8.uniqueResult();
        System.out.println("Precio maximo: " + resultado8);
        
        Query query9 = session.createQuery("select avg(a.precio) from Auto as a");
        double resultado9 = (Double) query9.uniqueResult();
        System.out.println("Promedio de precios: " + resultado9);
        */
        /*
        //Labo 04
        TestQueriesParametrizadas.obtenerAutosSegunCriterio(session, null, null);
        */
        /*
        //Labo 05
        TestPaginacion.obtenerAutosConPaginacion(session, 0, 2);
        */
        /*
        //Labo 06
        Query namedQuery = session.getNamedQuery("obtenerAutosCaros");
        List<Auto> autos = namedQuery.list();
        for(Auto a : autos) {
            System.out.println("Marca: " + a.getMarca());
            System.out.println("Modelo: " + a.getModelo());
        }
        */    
        
//Siempre ejecutar esto
        t.commit();
        session.close();
        sf.close();

    }
}
