package modelo;

//Importar anotaciones para trabajar con Hibernate
import java.util.List;
import javax.persistence.*;

//Para indicar que es una entidad.
@Entity
@Table(name="concesionarios")
public class Concesionario {

    @Id //Indicar que es un ID a Hibernate y PrimaryKey
    @GeneratedValue //Autogenerar ID
    private Long id;
    private String nombre;
    private String direccion;

    public Concesionario(String nombre, String direccion) {
        
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public Concesionario() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

  

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
