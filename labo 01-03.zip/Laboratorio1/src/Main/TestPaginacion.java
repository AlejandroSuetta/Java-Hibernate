package Main;

import java.util.List;
import modelo.Auto;
import org.hibernate.Query;
import org.hibernate.Session;

public class TestPaginacion {
    public static List obtenerAutosConPaginacion(Session s, int registroInicial, int cantidad) {
        Query querypag = s.createQuery("from Auto");
        querypag.setFirstResult(registroInicial);
        querypag.setMaxResults(cantidad);
        List<Auto> autos = querypag.list();
        for(Auto a : autos) {
            System.out.println("Marca: " + a.getMarca());
            System.out.println("Modelo: " + a.getModelo());
        }
        return autos;
    }
}
